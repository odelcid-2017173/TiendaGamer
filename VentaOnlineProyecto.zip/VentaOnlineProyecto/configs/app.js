'use strict'

const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const helmet = require('helmet');
const app = express();
const port = 3000;
const userRoutes = require('../src/routes/user.routes');
const productoRoutes = require('../src/routes/videogame.routes');
const categoriaRoutes = require('../src/routes/categories.routes');
const cartShopping = require('../src/routes/shoppingCart.routes');
const invoice = require('../src/routes/invoice.routes')

app.use(helmet());
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());
app.use(cors());
app.use('/user', userRoutes);
app.use('/producto', productoRoutes);
app.use('/cat', categoriaRoutes);
app.use('/cart', cartShopping);
app.use('/fac', invoice);



module.exports = app;