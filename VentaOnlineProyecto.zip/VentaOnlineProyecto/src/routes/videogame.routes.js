'use strict'

const productController = require('../controllers/videogame.controller');
const express = require('express');
const api = express.Router();
const mAuth = require('../services/authenticated');

api.get('/test', productController.test);
api.post('/createpProduc', [mAuth.ensureAuth, mAuth.isAdmin], productController.createProducto);
api.get('/getProduct', mAuth.ensureAuth, productController.getProducto);
api.put('/editProducto/:id', [mAuth.ensureAuth, mAuth.isAdmin], productController.editProducto);
api.delete('/deleteProducto/:id', [mAuth.ensureAuth, mAuth.isAdmin], productController.deleteProducto);
api.put('/editStock/:id', [mAuth.ensureAuth, mAuth.isAdmin], productController.stockcontrol);
api.get('/agotado', [mAuth.ensureAuth, mAuth.isAdmin],productController.notForSale);
module.exports = api; 