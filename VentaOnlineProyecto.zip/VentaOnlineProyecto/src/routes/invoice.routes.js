'use strict'

const facturController = require('../controllers/invoice.controller');
const express = require('express');
const api = express.Router();
const mdAuth = require('../services/authenticated');

api.get('/saveInvoice', mdAuth.ensureAuth, facturController.saveInvoice);

module.exports = api;