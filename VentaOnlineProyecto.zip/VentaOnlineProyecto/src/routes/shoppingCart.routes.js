'use strict'

const cartController = require('../controllers/shoppingCart.controller');
const express = require('express');
const api = express.Router(); 
const mdAuth = require('../services/authenticated');

api.post('/add',mdAuth.ensureAuth, cartController.saveCart);

module.exports = api;
