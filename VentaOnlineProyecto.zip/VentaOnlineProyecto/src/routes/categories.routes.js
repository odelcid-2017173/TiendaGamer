'use strict'

const express = require('express');
const categoriasController = require('../controllers/categories.controller');
const api = express.Router();
const mAuth = require('../services/authenticated');

api.post('/saveCategory', [mAuth.ensureAuth, mAuth.isAdmin], categoriasController.saveCategoria);
api.get('/getCategoria', [mAuth.ensureAuth, mAuth.isAdmin], categoriasController.getCategoria);
api.get('/getCategory/:id', [mAuth.ensureAuth, mAuth.isAdmin], categoriasController.getCategory);
api.put('/updateCategory/:id', [mAuth.ensureAuth, mAuth.isAdmin], categoriasController.updateCategoria);
api.delete('/deleteCategories/:id', [mAuth.ensureAuth, mAuth.isAdmin], categoriasController.deleteCategory);
api.get('/searchCategory', [mAuth.ensureAuth, mAuth.isAdmin],categoriasController.searchCategoria);

module.exports = api;