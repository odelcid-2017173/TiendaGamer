'use strict'

const userController = require('../controllers/user.controller');
const express = require('express');
const api = express.Router(); 
const mAuth = require('../services/authenticated');

api.get('/test', userController.test);
api.post('/register', userController.register);
api.post('/login', userController.login);
api.put('/update/:id', mAuth.ensureAuth, userController.update);
api.delete('/delete/:id', mAuth.ensureAuth, userController.delete);
api.get('/getUserProducto', mAuth.ensureAuth, userController.getUserProducto);
module.exports = api; 