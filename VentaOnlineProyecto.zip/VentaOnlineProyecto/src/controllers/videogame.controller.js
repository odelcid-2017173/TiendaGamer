'use strict'

const {validateData, searchUser,checkUpdate } = require('../utils/validate');

const Product = require('../models/videogame.model');

exports.test = (req,res)=>{
    return res.send({message: 'La funcion funciona'});
};

exports.createProducto = async(req, res)=>{
    try{
        const params = req.body;
        const data = {
            name: params.name,
            price: params.price,
            sell: params.sell,
            stock: params.stock
        }
const msg = validateData(data);
if(!msg){
    
            const product = new Product(data);
            await product.save();
            return res.send({message: 'Producto save'})
        } else return res.status(400).send(msg)
    
    }catch(err){
        console.log(err);
        return err;
    }
}

exports.getProducto = async(req, res)=>{
    try{
      const products = await Product.find();
      return res.send({products});  
    }catch(err){
        console.log(err);
        return err;
    }
}

exports.editProducto = async(req, res)=>{
    try{
        const productID = req.params.id;
        const params = req.body;
             const already = await searchUser(params.name); 
            if(!already){
                const productUpdate = await Product.findOneAndUpdate({_id: productID}, params,{new:true}).lean()
                return res.send({productUpdate, message: 'Producto update'});
            }else return res.send({message: 'Producto already taken'});             
        
    }catch(err){
        console.log(err);
        return err;
    } 
}

exports.deleteProducto = async(req, res)=>{
    try{
        const productID = req.params.id;
        const productDeleted = await Product.findOneAndDelete({_id: productID});
        if(productDeleted) return res.send({productDeleted, message: 'Account deleted'});
            return res.send({message:'Producto not found or already deleted'})
    }catch(err){
        console.log(err);
        return err;
    }
}

exports.stockcontrol = async (req, res)=>{
    try{
        const params = req.body;
        const productID = req.params.id;
        const data = {
            stock: params.stock
        }

        const check = await checkUpdate(params);
        if(check === true){
            const msg = validateData(data);
            const update = await Product.findOneAndUpdate({_id: productID}, params, {new:true});
            if(update){
                if(!msg){
                    return res.send({message: 'stock update', update});
                    }else return res.send({msg});
            }else return res.send({message: 'No existe'})    
        }else return res.send({message: 'This stock update the product'})
       
    }catch(err){
        console.log(err);
        return err;
    }
}


exports.notForSale = async(req,res)=>{
    try{
        const notForSale = await Product.find({stock:0})
        return res.send({notForSale})
    }catch(err){
        console.log(err);
        return err;
    }
}

