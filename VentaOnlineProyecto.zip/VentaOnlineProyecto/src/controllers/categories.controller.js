'use strict'

const {validateData, checkUpdate} = require('../utils/validate');
const Category = require('../models/categories.model');
const Product = require ('../models/videogame.model');

exports.saveCategoria = async (req, res)=>{
    try{
        const params = req.body;
        const data = {

            name: params.name,
            product: params.product

        };
        const msg = validateData(data);
        if(!msg){
        const category = new Category(data);
        await category.save();
        return res.send({message: 'Category saved', data});
        }else return res.send({message: 'Category not found or already save'});
    }catch(err){
        console.log(err);
        return err;
    }
}

exports.getCategoria = async(req, res)=>{
    try{
        const categories = await Category.find();
        return res.send({categories});
    }catch(err){
        console.log(err);
        return err;
    }
}

exports.getCategory = async(req, res)=>{
    try{
        const categoryId = req.params.id;
        const category = await Category.findOne({_id: categoryId});
        if(!category) return res.send({message: 'Category not found'});
        return res.send({category});
    }catch(err){
        console.log(err);
        return err;
    }
}


exports.updateCategoria = async(req, res)=>{
    try {
        const params = req.body;
        const categoriaId = req.params.id;
        const check = await checkUpdate(params);
        if (check === false) {
            return res.status(400).send({message: 'Data no recibida'});
        }else{
            const updateCategoria = await Category.findByIdAndUpdate({_id: categoriaId}, params, {new: true});
            return res.send({message: 'categoria actualizada', updateCategoria});
        }
    } catch (err) {
        console.log(err);
        return err;
    }
}

exports.deleteCategory = async(req, res)=>{
    try {
        const categoryDelete = await Category.findOne({name: 'Default'});
        const catId = req.params.id;
        const categoryExist = await Category.findOne({_id: catId});
        if (categoryExist){
            const productCategory = await Category.find({category:catId});
            if(!productCategory){
                await Category.findOneAndDelete({_id:categoryId});
                return res.send({message:'deleted category'});
            }else{
                await Product.updateMany({category:catId}, {category:categoryDelete},{multi:true});
                await Category.findByIdAndDelete({_id:catId});
                return res.send({message:'deleted category'});
            }
        }else{
            return res.status(404).send('Category not found');
        }
    }catch(err){
        console.log(err);
        return err;
    }
}

exports.searchCategoria = async(req, res)=>{
    try{
        const params = req.body;
        const data = {
            name: params.name
        };
        const msg = validateData(data);
        if(!msg){
            const categoria = await Category.find({name: {$regex:params.name, $options: 'i'}});
            return res.send({categoria});
        }else return res.status(400).send(msg);
    }catch(err){
        console.log(err);
        return err;
    }
}