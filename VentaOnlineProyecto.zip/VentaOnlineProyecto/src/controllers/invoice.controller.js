'use strict'

const Product = require('../models/videogame.model');
const Cart = require('../models/shoppingCart.model');


exports.saveInvoice = async (req, res) => {
    try {
        const userID = req.user.sub;
        const cart = await Cart.findOne({ user: userID });

        if (cart) {
            for (var i = 0; i < cart.products.length; i++) {
                const producId = cart.products[i].product;
                const quantity = cart.products[i].quantity;

                const product = await Product.findOne({ _id: producId });
                
                const resta = product.stock - quantity;
                if (resta <= 0) return res.send({ message: 'Not stock' });
                const data1 = {
                    stock: resta
                }
                await Product.findOneAndUpdate({ _id: producId }, data1, { new: true })
                
            }
        }
        return res.send({message: 'Purchased', cart})
    } catch (err) {
        console.log(err);
        return err;
    }
}