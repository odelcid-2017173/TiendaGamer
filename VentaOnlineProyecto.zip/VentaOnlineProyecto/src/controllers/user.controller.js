'use strict'
const { validateData, searchUser, encrypt, checkPassword, checkPermission, checkUpdate } = require('../utils/validate');
const User = require('../models/user.model');
const Product = require('../models/videogame.model')
const Shopping = require('../models/shoppingCart.model')
const jwt = require('../services/jwt');

exports.test = (req, res) => {
    return res.send({ message: 'Function test is running Proyecto Final' });

};

exports.register = async (req, res) => {
    try {
        const params = req.body;
        const data = {
            name: params.name,
            username: params.username,
            password: params.password,
            role: 'CLIENT'
        }

        const msg = validateData(data);

        if (!msg) {
            let userExist = await searchUser(params.username);
            if (!userExist) {
                data.email = params.email;
                data.phone = params.phone;
                data.password = await encrypt(params.password);

                let user = new User(data);
                await user.save();
                const users = await User.findOne({ username: params.username });
                console.log({ users })
                const data1 = {
                    user: users.id
                }
                let carrito = new Shopping(data1);
                await carrito.save();
                return res.send({ message: 'El usuario se guardo exitosamente' });
            } else {
                return res.send({ message: 'El nombre de usuario ya esta en uso, escoge otro' });
            }
        } else {
            return res.status(400).send(msg);
        }
    } catch (err) {
        console.log(err);
        return err;
    }
}
exports.login = async (req, res) => {
    try {
        const params = req.body;
        const data = {
            username: params.username,
            password: params.password
        }
        let msg = validateData(data);
        if (!msg) {
            let userExist = await searchUser(params.username);
            if (userExist && await checkPassword(params.password, userExist.password)) {
                const token = await jwt.createToken(userExist);
                return res.send({ token, message: 'Login successfuly' });
            } else {
                return res.send({ message: 'Username or password incorrect' })
            }
        } else {
            return res.status(400).send(msg)
        }
    } catch (err) {
        console.log(err)
        return err;
    }
}

exports.update = async (req, res) => {
    try {
        const userID = req.params.id;
        const params = req.body;
        const permission = await checkPermission(userID, req.user.sub);
        if (permission === false) return res.status(403).send({ messsage: 'wrong user' });
        else {
            const notUpdate = await checkUpdate(params);
            if (notUpdate === false) return res.status(400).send({ message: 'This params con only update by admin' })
            const already = await searchUser(params.username);
            if (!already) {
                const userUpdate = await User.findOneAndUpdate({ _id: userID }, params, { new: true }).lean()
                return res.send({ userUpdate, message: 'User update' });
            } else return res.send({ message: 'Username already taken' });
        }
    } catch (err) {
        console.log(err);
        return err;
    }
}

exports.delete = async (req, res) => {
    try {
        const userID = req.params.id;
        const permission = await checkPermission(userID, req.user.sub);
        if (permission === false) return res.status(403).send({ message: 'invalid token' });
        const userDeleted = await User.findOneAndDelete({ _id: userID });
        if (userDeleted) return res.send({ userDeleted, message: 'Account deleted' });
        return res.send({ message: 'User not found or already deleted' });
    } catch (err) {
        console.log(err);
        return err;
    }
}

exports.getUserProducto = async (req, res) => {
    try {
        const userID = req.params.id;
        const permission = await checkPermission(userID, req.user.sub);
        if (permission === true) {
            return res.status(403).send({ message: 'invalid token' });
        } else {
            const videogame = await Product.find();
            return res.send({ videogame });
        }

    } catch (err) {
        console.log(err);
        return err;
    }
}


