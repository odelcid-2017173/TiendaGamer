'use strict'

const Cart = require('../models/shoppingCart.model');
const Product = require('../models/videogame.model');
const { validateData } = require('../utils/validate');


exports.saveCart = async (req, res) => {
    try {
        const userId = req.user.sub;
        const params = req.body;
        const products = {
            product: params.product,
            quantity: params.quantity
        }
        const msg = validateData(products);
        
        if (!msg) {
            const sProduct = await Product.findOne({_id: products.product});
            const search = await Cart.findOne({user: userId });
            if(sProduct.stock > 0){
                if (search) {
                const update = await Cart.findOneAndUpdate({ _id: search.id }, { $push: { products: [{ product: products.product, quantity: products.quantity }] } });
                return res.send({ message: 'added product', update })
                }else{
                    return res.send({message: 'product not added'});
                }
            }else return res.send({message: 'sold out product'})
        }else return res.send(msg)
    } catch (err) {
        console.log(err);
        return err;
    }
}
