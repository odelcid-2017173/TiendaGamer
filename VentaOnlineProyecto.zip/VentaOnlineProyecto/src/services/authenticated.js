'use strict'

const jwt = require('jwt-simple');
const moment = require('moment');
const secretKey = 'CualquierDato';

exports.ensureAuth = (req, res, next)=>{
    if(!req.headers.authorization){
        return res.status(403).send({message: ' the request does not contain the autorization header '})
    }else{
        try{
            let token = req.headers.authorization.replace(/['"]+/g, '');
            var payload = jwt.decode(token, secretKey);
        }catch(err){
            console.log(err);
            return res.status(400).send({message:'Token is not valid'});
        }
        req.user = payload;
        next();
    }
}

exports.isAdmin = async(req, res, next)=>{
    try{
        const user = req.user;
        if(user.role === 'ADMIN') next()
        else return res.status(403).send({message: 'User unauthorized'})
    }catch(err){
        console.log(err);
    return err;
    } 
    
}