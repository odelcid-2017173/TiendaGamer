'use strict'

const User = require('../models/user.model');
const bcrypt = require('bcrypt-nodejs');

exports.validateData = (data)=>{
    let keys = Object.keys(data), msg = '';

    for(let key of keys){
        if(data[key] !== null && data[key] !== undefined && data[key] !== '') continue;
            msg += `The param ${key} is required\n` ;
     }  
     return msg.trim();
}

exports.searchUser = async (username)=>{
    try{
     let exist = User.findOne({username: username}).lean()  
     return exist;    
    }catch(err){


    }
}

exports.encrypt =  async (password)=>{
    try{
        return bcrypt.hashSync(password);
    }catch(err){
        console.log(err);
        return err;
    }
}

exports.checkPassword = async (password, hash)=>{
    try{
        return bcrypt.compareSync(password,hash);
    }catch(err){
        console.log(err);
        return err;
    }

}

exports.checkPermission = async (userID, sub)=>{
    try{
        if(userID != sub)
            return false;
        else
            return true;
    }catch(err){
        console.log(err);
        return err;
    }
}

exports.checkUpdate = async (User) =>{
    try{
        if(User.password || Object.entries(User).length === 0 || User.role)
            return false;
        else
            return true;
    }catch(err){
        console.log(err);
        return err;
    }
    
}

exports.deleteSensitiveData = async(data)=>{
    try{
        delete data.user.password;
        delete data.user.role;
        return data; 
    }catch(err){
        console.log(err);
        return err;
    }
}